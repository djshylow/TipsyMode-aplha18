# Donovan MegaStacks

## 7 Days 2 Die Modlet

This modlet increases the stack sizes on most items, increasing the amount of resources you can carry and/or store by a very large amount. Intended for those who prefer to not worry about storage space as much.

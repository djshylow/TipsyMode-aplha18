# Donovan BetterCement

## 7 Days 2 Die Modlet

Reworks the way concrete is created. It never made sense to me why you had to smelt stone to make cement mix, so I fixed that.

- The forge no longer creates cement mix, instead...
- Craft cement mix directly in the cement mixer with equal parts of sand and clay
- Concrete no longer requires sand, just cement mix and small rocks.

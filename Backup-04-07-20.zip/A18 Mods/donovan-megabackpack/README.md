# Donovan Mega Backpack

## 7 Days 2 Die Modlet

Increases the size of the player backpack to 120

# Donovan CraftJail

## 7 Days 2 Die Modlet

This small modlet adds the Jaildoor back into the game as a craftable item. Also allows shooting through jail door and bars.

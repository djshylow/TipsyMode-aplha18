# Donovan BetterSpears

## 7 Days 2 Die Modlet

Spears now do significantly more damange, making them viable end-game weapons.

Additionally, they can be used to butcher meat as well.

# Donovan BetterBandages

## 7 Days 2 Die Modlet

This modlet changes the way you craft first-aid bandages. Instead of requiring cloth and aloe, it now requires bandages and aloe.

This means that you can either craft normal bandages first out of cloth, and then make first-aid bandages or, more importantly, you can
use any normal bandages you already have and/or find and turn them directly into first-aid bandages.

Additionally, as of Alpha 18, we've moved the perk for First Aid bandanges to `Physician` level 1, and Medical Kits to `Physician` level 2.

# TipsyMode
Craftable Area's
TipsyWorkbench
Recipe>
| Resource | Qty | 
| --- | --- |
| resourceForgedIron | 100 |
| resourceMechanicalParts | 1000 |
| meleeToolWrench | 1 |
| meleeToolClawHammer | 1 |
| resourceWood | 6000 |
|  |  |

WeaponsMechine
Recipe>
| Resource | Qty | 
| --- | --- |
| resourceForgedSteel | 500 |
| resourceMechanicalParts | 1000 |
| meleeToolWrench | 1 |
| meleeToolClawHammer | 1 |
| resourceElectricParts | 1000 |

TIPSYGrill
Recipe> Still Thinking
| Resource | Qty | 
| --- | --- |
|  |  |
|  |  |
|  |  |
|  |  |
|  |  |


NEW Metarials > 

| Resource | Qty | Recipe | Qty |
| --- | --- | --- | --- |
| resourceElectronicParts | 1 | resourceMechanicalParts| 1 |
|  |  | resourceElectricParts| 1 |
| AdvanceRepairKit | 1 | resourceMechanicalParts | 1 |
|  |  | resourceElectricParts | 1 |
|  |  | resourceElectronicParts | 1 |
|  |  | resourceRepairKit | 1 |
| GoDKit | 1 | AdvanceMechaParts | 50 |
|  |  | resourceAcid | 5 |
|  |  | GunSprings | 50 |
|  |  | GunKit | 5 |
| GunKit | 1 | resourceAcid | 1 |
|  |  | resourceRepairKit | 50 |
| Perfect Steel | 1 | resourceForgedSteel | 100 |
| Perfect Iron | 1 | resourceForgedIron | 200 |
| GunBarrels | 1 | resourceMetalPipe | 50 |
| GunSprings | 1 | resourceSpring | 50 |
| GunTape | 1 | resourceDuctTape | 10 |
| AdvanceMechaParts | 1 | resourceMechanicalParts | 20 |
| AdvanceElectricParts | 1 | resourceElectricParts | 20 |
| AdvanceElectronicParts | 1 | resourceElectronicParts | 5 |
|  |  |  |  |
|  |  |  |  |
|  |  |  |  |
|  |  |  |  |
|  |  |  |  |
|  |  |  |  |
|  |  |  |  |
|  |  |  |  |
|  |  |  |  |

